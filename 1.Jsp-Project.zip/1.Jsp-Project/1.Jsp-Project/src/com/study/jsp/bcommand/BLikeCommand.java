package com.study.jsp.bcommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.study.jsp.dao.BDao;
import com.study.jsp.dao.BLikeDao;
import com.study.jsp.dto.BDto;
import com.study.jsp.dto.BLikeDto;
import com.study.jsp.dto.MemberDto;

public class BLikeCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session;
		session = request.getSession();
		
		String bId = request.getParameter("bId");
		String id = (String) session.getAttribute("id");
		session.getAttribute("bId");
		
		String check = "";
		try {
			check = (String) request.getParameter("check");			
			session.setAttribute("like", check);
		} catch (Exception e) {
			
		}
		BDao dao = new BDao();
		BLikeDao bLikeDao = new BLikeDao();
				
		bLikeDao.likeboard(bId, id, check);
		
		
		MemberDto memberDto = dao.membercontentView(id);
		BLikeDto bLikeDto = bLikeDao.likecontentView(id, bId); 
		
		request.setAttribute("like_content_view", bLikeDto); 
		request.setAttribute("member_content_view", memberDto); 
		
		
	}
	
}
